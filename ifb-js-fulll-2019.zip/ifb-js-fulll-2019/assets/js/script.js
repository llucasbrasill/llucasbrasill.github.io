// Exibir um Hello World com alert!
//alert("Olá Mundo!");


const convenios = document.getElementsByClassName("convenio");

var m = 0;


function mensagemErro(result) {

    var pesquisa = document.querySelectorAll('input[name=pegasearch]')[0].value;

    var erro =  document.getElementById('erro');

    if (pesquisa.length != 0) {
        
        if (result == 0) {
            erro.innerHTML = '<div class="alert alert-danger" role="alert">Não foi encontrado resultados para a busca de: <b>' + pesquisa + '</b> !</div>';
        } else {
            //erro.innerText = "encontrado!";
        }
    } else {
        erro.innerText = "";
    }

    
}

function pesquisarParceiros() {

    m = 0;
    var erro =  document.getElementById('erro');
    erro.innerText = "";
    var pesquisa = document.querySelectorAll('input[name=pegasearch]')[0].value;
   
    console.log(pesquisa);
    for (var index = 0; index < convenios.length; index++) {

      try {
        var palavras = document.querySelectorAll('.convenio img')[index].getAttribute('palavras');
      }
      catch(err) {
    
        console.log('Erro!');
       
      }


        var p = palavras.split(",");
        
        convenios[index].classList.remove('ocultar');

        for (var i = 0; i < p.length; i++) {
          if (pesquisa.length > 0) {
                if(pesquisa.toLowerCase() == p[i] || p[i].includes(pesquisa.toLowerCase())){
                    document.querySelectorAll('.convenio')[index].classList.remove('ocultar');
                    m = 1;
                } else {
                    document.querySelectorAll('.convenio')[index].classList.add('ocultar');
                }
          } 
         
        }
    

    }

 console.log(m);
 mensagemErro(m);
}

